#include <stdio.h>
#include <stdlib.h>
/*Declaração/Definição das funções*/
int f(int a){
    return a;
}

int g(int b){
    return 1;
}

int main(){

    float b = 3.12345;
    printf("%f ", floor(b));


	return 0;
}


/* Definição das funções*/
