#include <stdio.h>
#define MAX 10
/*Declaração/Definição das funções*/

int main(){
    float array[MAX] = {2.1, 4.23, 6.456, 2.71828, 3.1415926, 5};
    double array2[MAX] = {2.1, 4.23, 6.456, 2.71828, 3.1415926, 5};
    int i;
    int tam = 6;

    printf("Float\n");
    for(i = 0; i < tam; i++){
        printf("%f\n", array[i]);
    }

    printf("\nDouble\n");
    for(i = 0; i < tam; i++){
        printf("%g\n", array2[i]);
    }


	return 0;
}


/* Definição das funções*/
