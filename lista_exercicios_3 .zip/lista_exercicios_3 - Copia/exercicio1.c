#include <stdio.h>
#define MAX 10
/*Declaração/Definição das funções*/

int main(){
    int array[MAX] = {2, 4, 6, 1, 3, 5};
    int i;
    int tam = 6;

    for(i = 0; i < tam; i++){
        printf("%d ", array[i]);
    }


	return 0;
}


/* Definição das funções*/
